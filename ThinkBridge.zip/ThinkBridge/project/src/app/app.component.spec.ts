import { FormsModule } from '@angular/forms';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { BrowserModule } from '@angular/platform-browser';
import { TestBed, async, ComponentFixture, fakeAsync, tick } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppComponent } from './app.component';
import { Observable } from 'rxjs';
import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';
import * as worldData from '../assets/mock-data-worldinfo.json';

class MockWorldDataInfo {
  worldInfo: any = worldData[1];

  fetchData(): any {
    let countryData;
    const url = 'http://api.worldbank.org/v2/country?format=json';
    /* this.http.get(url).subscribe((response) => {
       countryData = response[1];
    }); */
    return countryData;
  }

}

describe('AppComponent', () => {
  let component: AppComponent;
  let fixture: ComponentFixture<AppComponent>;
  let serviceWorldData;
  let data;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        BrowserModule,
        AppRoutingModule,
        HttpClientModule,
        FormsModule,
      ],
      declarations: [
        AppComponent
      ],
      providers: [HttpClientModule, MockWorldDataInfo]
    }).compileComponents();
    serviceWorldData = TestBed.get(MockWorldDataInfo);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create the app', () => {
    expect(component).toBeTruthy();
  });

  it(`should have as title 'World Bank Information'`, () => {
    expect(component.title).toEqual('World Bank Information');
  });

  it('should have correct name of the country in dropdown', async () => {
    let obj;
    const name = 'Australia';
    await component.fetchData();
    obj = serviceWorldData.worldInfo[13];
    fixture.whenStable().then(() => {
      expect(component.worldBankData[13].name).toBe(obj.name);
    }).catch(() => { });
    expect(obj.name).toBe(name);
  });

  it('should have correct Capital City', async () => {
    let obj;
    const capital = 'Canberra';
    await component.fetchData();
    obj = serviceWorldData.worldInfo[13];
    fixture.whenStable().then(() => {
      expect(component.worldBankData[13].capitalCity).toBe(obj.capitalCity);
    }).catch(() => { });
    expect(obj.capitalCity).toBe(capital);
  });

  it('should have correct Longitude', async () => {
    let obj;
    const longitude = '149.129';
    await component.fetchData();
    obj = serviceWorldData.worldInfo[13];
    fixture.whenStable().then(() => {
      expect(component.worldBankData[13].longitude).toBe(obj.longitude);
    }).catch(() => { });
    expect(obj.longitude).toBe(longitude);
  });

  it('should have correct Latitude', async () => {
    let obj;
    const latitude = '-35.282';
    await component.fetchData();
    obj = serviceWorldData.worldInfo[13];
    fixture.whenStable().then(() => {
      expect(component.worldBankData[13].latitude).toBe(obj.latitude);
    }).catch(() => { });
    expect(obj.latitude).toBe(latitude);
  });
})