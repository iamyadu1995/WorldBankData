import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'World Bank Information';
  worldBankData: Array<any>;
  selectedValue: any;
  constructor(private http: HttpClient) {

  }

  ngOnInit() {
    this.fetchData();
  }

  fetchData() {
    const url = 'http://api.worldbank.org/v2/country?format=json';
    this.http.get(url).subscribe((response) => {
      const countryData = response[1];
      if (countryData) {
        this.worldBankData = countryData;
        this.selectedValue = countryData[0];
      }
    });
  }

  

}
